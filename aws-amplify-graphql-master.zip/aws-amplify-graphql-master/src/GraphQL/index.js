export { default as QueryListPictures } from "./QueryListPictures";
export { default as MutationCreatePicture } from "./MutationCreatePicture";
